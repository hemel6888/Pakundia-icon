// Firebase config: আপনার দেওয়া তথ্য
const firebaseConfig = {
  apiKey: "AIzaSyDvL4LmWPFJ7pllPu4OaAgD3lsKo2ULhsY",
  authDomain: "pakundiagallery.firebaseapp.com",
  projectId: "pakundiagallery",
  storageBucket: "pakundiagallery.appspot.com", // ✅ ঠিক করে দিয়েছি
  messagingSenderId: "197077235015",
  appId: "1:197077235015:web:a2d0288947c15e350f8862",
  measurementId: "G-NRV9KB4LYY"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);

const storage = firebase.storage();
const db = firebase.firestore();
const galleryContainer = document.getElementById("galleryContainer");

// Load existing images from Firestore
function loadGallery() {
  db.collection("images").orderBy("timestamp", "desc").get().then((snapshot) => {
    snapshot.forEach(doc => {
      const data = doc.data();
      const img = document.createElement("img");
      img.src = data.url;
      img.alt = data.name;
      galleryContainer.appendChild(img);
    });
  });
}

loadGallery();

// Upload image
document.getElementById("uploadForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const name = document.getElementById("uploaderName").value;
  const file = document.getElementById("imageFile").files[0];

  if (!file) return alert("ছবি নির্বাচন করুন");

  const storageRef = storage.ref("images/" + Date.now() + "_" + file.name);

  storageRef.put(file).then(snapshot => {
    return snapshot.ref.getDownloadURL();
  }).then(url => {
    return db.collection("images").add({
      name: name,
      url: url,
      timestamp: firebase.firestore.FieldValue.serverTimestamp()
    });
  }).then(() => {
    alert("ছবি সফলভাবে আপলোড হয়েছে!");
    galleryContainer.innerHTML = "";
    loadGallery();
    document.getElementById("uploadForm").reset();
  }).catch(err => {
    console.error(err);
    alert("আপলোডে সমস্যা হয়েছে!");
  });
});